/*
 * ex2.cpp
 *
 *  Created on: Apr 19, 2016
 *      Author: kahle
 */



//#include <bits/shared_ptr_base.h>
//#include <bits/shared_ptr_base.h>
#include <dolfin/common/Array.h>
#include <dolfin/common/NoDeleter.h>
#include <dolfin/fem/DirichletBC.h>
#include <dolfin/fem/Equation.h>
#include <dolfin/fem/solve.h>
#include <dolfin/function/Expression.h>
#include <dolfin/function/Function.h>
#include <dolfin/function/FunctionSpace.h>
#include <dolfin/generation/UnitSquareMesh.h>
#include <dolfin/fem/assemble.h>
//#include <dolfin/io/File.h>
#include <dolfin/log/log.h>
#include <dolfin/mesh/MeshGeometry.h>
#include <dolfin/mesh/SubDomain.h>
#include <dolfin/refinement/PlazaRefinementND.h>
#include <cassert>
#include <memory>
#include <string>

#include <cmath>

#include "ex2_sys.h"



using std::endl;
using std::cout;



class ExactSolution : public dolfin::Expression
{
public:
	ExactSolution(unsigned geometric_dimension)
:Expression(),gdim(geometric_dimension){}


	void eval(dolfin::Array<double>& val, const dolfin::Array<double>& x)const
	{
		assert(val.size() == 1);
		assert(x.size() == gdim);
		assert(gdim==2);

		double x1 = x[0];
		double x2 = x[1];


		/*
		 * EXERCISE: fill in the correct value into val[0]
		 */


		val[0] = std::sin(M_PI*x1)*std::sin(2*M_PI*x2);
	}

private:
	const unsigned gdim;
};



/*
 * this class describes the volume force f on the right hand side of the equation
 */
class VolumeForce : public dolfin::Expression
{

public:
	VolumeForce(unsigned geometric_dimension)
:Expression(),gdim(geometric_dimension){}

	void eval(dolfin::Array<double>& val, const dolfin::Array<double>& x)const
	{
		assert(val.size() == 1);
		assert(x.size() == gdim);
		assert(gdim==2);

		double x1 = x[0];
		double x2 = x[1];

		/*
		 * EXERCISE: fill in the correct value into val[0]
		 */


		val[0] = std::sin(M_PI*x1)*std::sin(2*M_PI*x2)*5*M_PI*M_PI;

		
	}

private:
	const unsigned gdim;


};

/*
 * this class describes the Dirichlet boundary data u==g on \partial \Omega
 */
class BoundaryData : public dolfin::Expression
{

public:
	BoundaryData(unsigned geometric_dimension)
:Expression(),gdim(geometric_dimension){}

	void eval(dolfin::Array<double>& val, const dolfin::Array<double>& x)const
	{
		assert(val.size() == 1);
		assert(x.size() == gdim);
		assert(gdim==2);

		double x1 = x[0];
		double x2 = x[1];

		val[0] = 0.0;

	}

private:
	const unsigned gdim;


};



/*
 * this class describes the points on the boundary of \Omega, i.e. where to apply Dirichlet bonudary data
 */
class Boundary : public dolfin::SubDomain
{

public:

	bool inside(const dolfin::Array<double>& x, bool on_boundary)const
	{
		//every point x on the boundary is inside the Dirichlet part of the boundary
		return on_boundary;
	}

};


double error_L2(const dolfin::Function& uh, const dolfin::Expression& u_exact)
{

	/*
	 * EXERCISE: fill out, requires changes in ex2_sys.ufl
	 */
	ex2_sys::Form_err_L2 a(uh.function_space()->mesh());
	a.set_coefficient("u",dolfin::reference_to_no_delete_pointer(u_exact));
	a.set_coefficient("uh",dolfin::reference_to_no_delete_pointer(uh));

	return std::sqrt(dolfin::assemble(a));

	//return 0.0;
}

double error_H10(const dolfin::Function& uh, const dolfin::Expression& u_exact)
{
	ex2_sys::Form_err_H10 a(uh.function_space()->mesh());
	a.set_coefficient("u",dolfin::reference_to_no_delete_pointer(u_exact));
	a.set_coefficient("uh",dolfin::reference_to_no_delete_pointer(uh));

	return std::sqrt(dolfin::assemble(a));
}



/*
 * Given a Mesh mesh,
 * create the FunctionSpace V
 * together with the forms a and b,
 * further create boundary data
 */
void prepareProblem(std::shared_ptr<dolfin::FunctionSpace>& V,
		std::shared_ptr<dolfin::Form>& a,
		std::shared_ptr<dolfin::Form>& b,
		std::shared_ptr<dolfin::DirichletBC>& bc,
		const std::shared_ptr<dolfin::Mesh>& mesh,
		const VolumeForce& f,
		const BoundaryData& g,
		const Boundary& bnd,
		const std::string& finite_element_type)
{

	if (finite_element_type == "linear")
	{
		// NOTE: here: Trialspace (i.e. Ansatzspace) == Testspace
		V.reset(new ex2_sys::Form_a1::TrialSpace(mesh));
		a.reset(new ex2_sys::Form_a1(V,V));

		b.reset((new ex2_sys::Form_b1(V)));
	}
	else if (finite_element_type == "quadratic")
	{
		/*
		 * EXERCISE: fill in for quadratic finite elements (see ex2_sys.ufl and ex2_sys.h)
		 */
		V.reset(new ex2_sys::Form_a2::TrialSpace(mesh));
		a.reset(new ex2_sys::Form_a2(V,V));

		b.reset((new ex2_sys::Form_b2(V)));
	}
	else
	{
		dolfin::dolfin_error("ex2.cpp",__func__,"unsupported finite element type: %s",finite_element_type.c_str());
	}

	//Append the volume force to the equation
	b->set_coefficient(0,dolfin::reference_to_no_delete_pointer(f));

	//create the Dirichlet boundary data u==g on bnd
	bc.reset(new dolfin::DirichletBC(*V,g,bnd));

}



/*
 * overwrites the mesh with a globally refined version
 */
void refineMesh(dolfin::Mesh& mesh)
{
	dolfin::Mesh mesh_old(mesh);
	dolfin::PlazaRefinementND::refine(mesh,mesh_old,true,false);
}


/*
 * the main is the entry to the program
 */
int main(int argc, char* argv[])
{


	unsigned n_iter = 5;

	// arrays to store the measured errors
	dolfin::Array<double> h(n_iter);
	dolfin::Array<double> err_L2(n_iter);
	dolfin::Array<double> err_H10(n_iter);


	//create the Galerkin FE discretization: a grid with 10x10 intervals per direction
	std::shared_ptr<dolfin::Mesh> mesh(new dolfin::UnitSquareMesh(10,10,"crossed"));


	//the description of the problem: FunctionSpace, bilinear a and linear form b
	std::shared_ptr<dolfin::FunctionSpace> V;
	std::shared_ptr<dolfin::Form> a;
	std::shared_ptr<dolfin::Form> b;

	std::shared_ptr<dolfin::DirichletBC> bc;

	/*
	 * this data that is independent of the mesh and thus of the FunctionSpace
	 */

	Boundary bnd;//create a description of the boundary

	BoundaryData g(mesh->geometry().dim());//... and of the boundary data

	VolumeForce f(mesh->geometry().dim());//... and finally the volume force

	ExactSolution u(mesh->geometry().dim());//the exact solution


	/* EXERCISE: choose "linear" or "quadratic" */
	std::string finite_element_type = "linear";
	//std::string finite_element_type = "quadratic";

	dolfin::File out("uh.pvd");

	for (unsigned iter = 0;iter<n_iter;++iter)
	{
		dolfin::info("Start solving PDE on step %u using '%s' elements",iter,finite_element_type.c_str());

		if (iter)
		{//refine mesh
			refineMesh(*mesh);
		}


		prepareProblem(V,a,b,bc,mesh,f,g,bnd,finite_element_type);



		//we want to solve a(u,v) == b(v)
		dolfin::Equation eq(a,b);

		//this will be the solution of the equation
		dolfin::Function uh(V);
		uh.rename("uh","u_label");

		//solve the equation (a(u,v) = b(v) for all v) with the given boundary data 'bc'
		dolfin::solve(eq,uh,*bc);

		out<<uh;



		//now uh holds the solution on the current mesh

		h[iter] = mesh->hmax();

		//EXERCISE: Evaluate the L2 and H10 errors
		err_L2[iter] = error_L2(uh, u);
		err_H10[iter] = error_H10(uh,u);



	}//end loop for solving equation on sequence of globally refined meshes

	dolfin::info("PDE solved for sequence of grids, start calculating error decay rate");


	dolfin::Array<double> rate_L2(n_iter);
	dolfin::Array<double> rate_H10(n_iter);

	/*
	 * EXERCISE: calculate the corresponding rates; NOTE: rate_*[0] = 0.0 used for output
	 */

	for (unsigned i=1;i<rate_L2.size();++i)
	{
		rate_L2[i] = log(err_L2[i]/err_L2[i-1])/log(h[i]/h[i-1]);
		rate_H10[i] = log(err_H10[i]/err_H10[i-1])/log(h[i]/h[i-1]);
	}
	
	//	rate_L2[0] = log(err_L2[i]/err_L2[i+1])/log(h[i]/h[i+1]);
	//	rate_H10[0] = log(err_H10[i]/err_H10[i+1])/log(h[i]/h[i+1]);


	dolfin::info("%10.8s %10.8s %10.8s %10.8s %10.8s","h","||e||_L2","alpha","||e||_H10","beta");

	for (unsigned i=0;i<rate_H10.size();++i)
	{
		dolfin::info("%10.8f %10.8f %10.8f %10.8f %10.8f",h[i],err_L2[i],rate_L2[i],err_H10[i],rate_H10[i]);
	}

}


